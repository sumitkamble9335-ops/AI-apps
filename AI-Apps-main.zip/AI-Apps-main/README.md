AI Apps library
